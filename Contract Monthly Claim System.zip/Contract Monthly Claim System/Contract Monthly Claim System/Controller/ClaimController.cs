﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Contract_Monthly_Claim_System.Models;

namespace Contract_Monthly_Claim_System.Controllers
{
    public class ClaimController : Controller
    {
        private static List<Claim> claims = new List<Claim>();

       
        public IActionResult Submit()
        {
            return View();
        }

        
        [HttpPost]
        public IActionResult Submit(string lecturerName, int hoursWorked, decimal hourlyRate)
        {
            var claim = new Claim
            {
                Id = claims.Count + 1,
                LecturerName = lecturerName,
                HoursWorked = hoursWorked,
                HourlyRate = hourlyRate
            };

            claims.Add(claim);
            return RedirectToAction("ManagerView");
        }

       
        [HttpPost]
        public IActionResult Upload(int claimId, IFormFile file)
        {
            var claim = claims.FirstOrDefault(c => c.Id == claimId);
            if (claim != null && file != null)
            {
                var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                if (!Directory.Exists(uploadPath))
                {
                    Directory.CreateDirectory(uploadPath);
                }

                var filePath = Path.Combine(uploadPath, file.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                claim.Documents.Add(new Document
                {
                    FileName = file.FileName,
                    FilePath = filePath
                });
            }

            return RedirectToAction("ManagerView");
        }

        
        public IActionResult ManagerView()
        {
            return View(claims);
        }

        
        public IActionResult Approve(int id)
        {
            var claim = claims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = "Approved";
            }
            return RedirectToAction("ManagerView");
        }

       
        public IActionResult Reject(int id)
        {
            var claim = claims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = "Rejected";
            }
            return RedirectToAction("ManagerView");
        }
    }
}

