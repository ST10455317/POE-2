﻿namespace Contract_Monthly_Claim_System.Models
{
    public class Document
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
    }
}

